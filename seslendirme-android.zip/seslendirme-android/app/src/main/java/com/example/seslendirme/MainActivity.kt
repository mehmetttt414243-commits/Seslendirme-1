package com.example.seslendirme

import android.Manifest
import android.content.pm.PackageManager
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.RandomAccessFile
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.concurrent.thread

class MainActivity : AppCompatActivity() {

    private companion object {
        const val SAMPLE_RATE = 22050
    }

    private lateinit var serverUrl: EditText
    private lateinit var textInput: EditText
    private lateinit var status: TextView
    private lateinit var btnRecord: Button
    private lateinit var btnSpeak: Button
    private lateinit var btnPlay: Button

    private val refFile by lazy { File(filesDir, "referans.wav") }
    private val outFile by lazy { File(cacheDir, "cikti.wav") }

    @Volatile private var recording = false
    private var player: MediaPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        serverUrl = findViewById(R.id.serverUrl)
        textInput = findViewById(R.id.textInput)
        status = findViewById(R.id.status)
        btnRecord = findViewById(R.id.btnRecord)
        btnSpeak = findViewById(R.id.btnSpeak)
        btnPlay = findViewById(R.id.btnPlay)

        val prefs = getSharedPreferences("ayar", MODE_PRIVATE)
        serverUrl.setText(prefs.getString("sunucu", ""))

        btnRecord.setOnClickListener {
            if (recording) {
                recording = false
            } else {
                startRecording()
            }
        }
        btnSpeak.setOnClickListener {
            prefs.edit().putString("sunucu", serverUrl.text.toString().trim()).apply()
            speak()
        }
        btnPlay.setOnClickListener { play() }

        if (refFile.exists()) status.text = "Kayıtlı referans ses var."
    }

    private fun setStatus(s: String) = runOnUiThread { status.text = s }

    // ---------- Kayıt (WAV, 16-bit mono PCM) ----------
    private fun startRecording() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
            != PackageManager.PERMISSION_GRANTED
        ) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 1)
            setStatus("Mikrofon izni verin, sonra tekrar basın.")
            return
        }
        recording = true
        btnRecord.text = "Kaydı durdur"
        setStatus("Kayıt yapılıyor... 10-15 saniye net konuşun.")

        thread {
            val minBuf = AudioRecord.getMinBufferSize(
                SAMPLE_RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
            )
            val rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT, minBuf * 2
            )
            val pcm = ByteArrayOutputStream()
            val buf = ByteArray(minBuf)
            rec.startRecording()
            while (recording) {
                val n = rec.read(buf, 0, buf.size)
                if (n > 0) pcm.write(buf, 0, n)
            }
            rec.stop()
            rec.release()
            writeWav(refFile, pcm.toByteArray())
            val sn = pcm.size() / 2 / SAMPLE_RATE
            runOnUiThread { btnRecord.text = "1) Referans sesi kaydet (başlat)" }
            setStatus("Referans ses kaydedildi (~$sn sn).")
        }
    }

    private fun writeWav(file: File, pcm: ByteArray) {
        RandomAccessFile(file, "rw").use { f ->
            f.setLength(0)
            val byteRate = SAMPLE_RATE * 2
            fun i32(v: Int) = byteArrayOf(
                v.toByte(), (v shr 8).toByte(), (v shr 16).toByte(), (v shr 24).toByte()
            )
            fun i16(v: Int) = byteArrayOf(v.toByte(), (v shr 8).toByte())
            f.write("RIFF".toByteArray()); f.write(i32(36 + pcm.size))
            f.write("WAVE".toByteArray()); f.write("fmt ".toByteArray())
            f.write(i32(16)); f.write(i16(1)); f.write(i16(1))
            f.write(i32(SAMPLE_RATE)); f.write(i32(byteRate))
            f.write(i16(2)); f.write(i16(16))
            f.write("data".toByteArray()); f.write(i32(pcm.size))
            f.write(pcm)
        }
    }

    // ---------- Sunucuya gönder, sonucu al ----------
    private fun speak() {
        val base = serverUrl.text.toString().trim().trimEnd('/')
        val text = textInput.text.toString().trim()
        when {
            base.isEmpty() -> { setStatus("Sunucu adresini girin."); return }
            !refFile.exists() -> { setStatus("Önce referans ses kaydedin."); return }
            text.isEmpty() -> { setStatus("Metin girin."); return }
        }
        setStatus("Seslendiriliyor... (CPU'da birkaç dakika sürebilir)")
        btnSpeak.isEnabled = false

        thread {
            try {
                val boundary = "----ses" + System.currentTimeMillis()
                val conn = URL("$base/konus").openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.doOutput = true
                conn.connectTimeout = 15000
                conn.readTimeout = 10 * 60 * 1000
                conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=$boundary")

                conn.outputStream.use { os ->
                    fun w(s: String) = os.write(s.toByteArray(Charsets.UTF_8))
                    w("--$boundary\r\nContent-Disposition: form-data; name=\"metin\"\r\n\r\n")
                    w(text + "\r\n")
                    w("--$boundary\r\nContent-Disposition: form-data; name=\"ses\"; filename=\"referans.wav\"\r\n")
                    w("Content-Type: audio/wav\r\n\r\n")
                    os.write(refFile.readBytes())
                    w("\r\n--$boundary--\r\n")
                }

                if (conn.responseCode != 200) {
                    setStatus("Sunucu hatası: ${conn.responseCode}")
                } else {
                    conn.inputStream.use { ins -> outFile.outputStream().use { ins.copyTo(it) } }
                    setStatus("Hazır, çalınıyor.")
                    play()
                }
            } catch (e: Exception) {
                setStatus("Bağlantı hatası: ${e.message}")
            } finally {
                runOnUiThread { btnSpeak.isEnabled = true }
            }
        }
    }

    private fun play() {
        if (!outFile.exists()) { setStatus("Henüz sonuç yok."); return }
        runOnUiThread {
            player?.release()
            player = MediaPlayer().apply {
                setDataSource(outFile.absolutePath)
                prepare()
                start()
            }
        }
    }

    override fun onDestroy() {
        recording = false
        player?.release()
        super.onDestroy()
    }
}
