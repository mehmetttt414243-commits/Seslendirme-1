"""
Seslendirme sunucusu (XTTS-v2). Android uygulaması buraya bağlanır.

Kurulum:
    pip install coqui-tts fastapi uvicorn python-multipart

Çalıştırma:
    uvicorn server:app --host 0.0.0.0 --port 8000

Telefon ve bilgisayar aynı Wi-Fi'de olmalı. Uygulamaya şu adresi yazın:
    http://BILGISAYAR_IP:8000
(Windows'ta IP için: ipconfig, Linux/Mac'te: ifconfig / ip a)
"""

import os
import tempfile

import torch
from fastapi import FastAPI, File, Form, UploadFile
from fastapi.responses import FileResponse
from TTS.api import TTS

cihaz = "cuda" if torch.cuda.is_available() else "cpu"
print(f"Model yükleniyor ({cihaz})...")
tts = TTS("tts_models/multilingual/multi-dataset/xtts_v2").to(cihaz)

app = FastAPI()


@app.get("/")
def saglik():
    return {"durum": "hazir", "cihaz": cihaz}


@app.post("/konus")
def konus(metin: str = Form(...), ses: UploadFile = File(...)):
    klasor = tempfile.mkdtemp()
    ref = os.path.join(klasor, "referans.wav")
    cikti = os.path.join(klasor, "cikti.wav")
    with open(ref, "wb") as f:
        f.write(ses.file.read())
    tts.tts_to_file(
        text=metin,
        speaker_wav=ref,
        language="tr",
        file_path=cikti,
        split_sentences=True,
    )
    return FileResponse(cikti, media_type="audio/wav")
