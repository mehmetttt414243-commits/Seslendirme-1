# Google Colab'da sunucuyu çalıştırmak için (bilgisayar gerekmez).
# colab.research.google.com > Yeni not defteri > Çalışma zamanı > Çalışma zamanı türünü değiştir > T4 GPU
# Aşağıdaki bölümleri ayrı hücrelere yapıştırıp sırayla çalıştırın.

# ---------- HÜCRE 1: kurulum ----------
# !pip install -q coqui-tts fastapi uvicorn python-multipart nest_asyncio

# ---------- HÜCRE 2: server.py dosyasını yükleyin ----------
# Sol taraftaki dosyalar simgesinden server.py dosyasını Colab'a yükleyin
# (veya içeriğini %%writefile server.py ile yapıştırın).

# ---------- HÜCRE 3: tünel + sunucu ----------
# !wget -q https://github.com/cloudflare/cloudflared/releases/latest/download/cloudflared-linux-amd64 -O cloudflared
# !chmod +x cloudflared

import re
import subprocess
import threading
import time

tunel = subprocess.Popen(
    ["./cloudflared", "tunnel", "--url", "http://localhost:8000"],
    stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True,
)


def adres_bul():
    for satir in tunel.stdout:
        m = re.search(r"https://[a-z0-9-]+\.trycloudflare\.com", satir)
        if m:
            print("\n>>> Uygulamaya bu adresi yazın:", m.group(0), "\n")
            break


threading.Thread(target=adres_bul, daemon=True).start()
time.sleep(2)

import nest_asyncio
import uvicorn

nest_asyncio.apply()
uvicorn.run("server:app", host="0.0.0.0", port=8000)
