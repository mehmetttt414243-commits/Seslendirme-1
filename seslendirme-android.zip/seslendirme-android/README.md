# Seslendirme (Android + Sunucu)

Telefon uygulaması sesinizi kaydeder, metinle birlikte sunucuya gönderir; sunucu XTTS-v2 ile
referans sesinize benzer Türkçe seslendirme üretir ve telefon çalar.

## 1) Sunucu (bilgisayar veya Colab)
    cd sunucu
    pip install coqui-tts fastapi uvicorn python-multipart
    uvicorn server:app --host 0.0.0.0 --port 8000

Telefon ve bilgisayar aynı Wi-Fi'de olmalı. Bilgisayarın IP adresini öğrenin
(Windows: `ipconfig`, Mac/Linux: `ip a`). Güvenlik duvarında 8000 portuna izin verin.

## 2) APK oluşturma
1. Android Studio'yu kurun (https://developer.android.com/studio).
2. File > Open ile bu klasörü (`seslendirme-android`) açın, Gradle senkronizasyonunun bitmesini bekleyin.
3. Menü: Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK: `app/build/outputs/apk/debug/app-debug.apk`
5. Dosyayı telefona aktarıp açın ("bilinmeyen kaynaklardan yükleme" iznini verin).

## 3) Kullanım
1. Uygulamaya sunucu adresini yazın: `http://BILGISAYAR_IP:8000`
2. "Referans sesi kaydet" ile 10-15 sn net konuşun, tekrar basıp durdurun.
3. Metni yazın, "Seslendir"e basın.

## Notlar
- Uygulama HTTP (şifresiz) kullanır; yalnızca kendi ağınızda kullanın.
- GPU'suz bilgisayarda seslendirme yavaş olur.
- Yalnızca kendi sesinizi veya izin aldığınız kişilerin sesini kullanın.
- XTTS-v2 ticari olmayan kullanım lisansına (CPML) sahiptir.
